#include <stdio.h>
int main(){
  printf("Vaibhav Gupta | 25583009 | Advanced Instrumentation & Artificial Intelligence");
}