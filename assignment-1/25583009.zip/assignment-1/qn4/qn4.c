#include <stdio.h>
int main(){
  printf("Hello World");
  printf("\n");
  printf("\"Hello World\"");
  printf("\n");
  printf("This is \\n a line");
  printf("\n");
  printf("How\tare\tyou");
  printf("\n");
  printf("Hello\n\tWorld!");
  printf("\n");
  printf("\?\?!");
  printf("\n");
  printf("Good/\\Day!");
  printf("\n");
  printf("For printing \\n we use \\\\n");
  printf("\n");
  printf("\"He\"llo wo\"rld");
  printf("\n");
  return 0;
}