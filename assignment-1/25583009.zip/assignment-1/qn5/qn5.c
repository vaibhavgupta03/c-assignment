#include <stdio.h>

int main(){
  if(printf("\"Hello World\"")){
    
  }
  return 0;
}