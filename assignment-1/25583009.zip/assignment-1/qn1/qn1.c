#include <stdio.h>

int main(){
  printf("*********\n*\t*\n*\t*\n*\t*\n*\t*\n*\t*\n*\t*\n*\t*\n*\t*\n*********");
  return 0;
}