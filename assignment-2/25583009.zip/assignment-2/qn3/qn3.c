#include <stdio.h>

int main(){
  int a;
  float b;
  char c;
  double d;
  printf("The size of int data type is : %d\n", sizeof(a));
  printf("The size of float data type is : %d\n", sizeof(b));
  printf("The size of char data type is : %d\n", sizeof(c));
  printf("The size of double data type is : %d", sizeof(d));
  return 0;
}