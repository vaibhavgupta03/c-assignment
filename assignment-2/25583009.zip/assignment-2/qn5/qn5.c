#include <stdio.h>
#include <math.h>

int main(){
  float e = 2.718281828;
  printf("%.0f\n", e);
  printf("%.0f.\n",round(e));
  printf("%.1f\n",e);
  printf("%.2f\n",e);
  printf("%.6f\n",e);
  printf("%.6f\n",e);
  printf("%.7f\n",e);
  return 0;
}